<header style = "width: 100%;">
 <div class= "div1">
  <img style= "width:100%;" src= "assets/k1.jpg">
 <div>

 <div class= "div2">
  <img style= "width: 7%; margin-left: 28vh; padding-top: 13px; padding-bottom: 13px;" src= "assets/icon1.webp">
  <img style= "width: 5%; margin-left: 8vh; padding-top: 13px; padding-bottom: 13px;" src= "assets/icon2.webp">  
  <img style= "width: 7%; margin-left: 8vh; padding-top: 13px; padding-bottom: 13px;" src= "assets/icon3.webp">  
  <img style= "width: 7%; margin-left: 8vh; padding-top: 13px; padding-bottom: 13px;" src= "assets/icon4.webp">  
  <img style= "width: 7%; margin-left: 8vh; padding-top: 13px; padding-bottom: 13px;" src= "assets/icon5.webp">  
  <img style= "width: 7%; margin-left: 8vh; padding-top: 13px; padding-bottom: 13px;" src= "assets/icon6.webp">  
  <img style= "width: 5%; margin-left: 8vh; padding-top: 13px; padding-bottom: 13px;" src= "assets/icon7.webp">    
 </div>

 <div class= "div3">
    <ul>
      <li><a href= "index.php"> <img style= "width: 23%; margin-left: 12dvh" src= "assets/k10.png"> </a> </li>
      <li style= "margin-left: -23vh;"><a href= #> Store Locator </a> </li>
      <li><a href= #> Sell on Konga </a></li>
      <li  class= "searchli"><a href= #> <input type= "text" style= "font-family: Bahnschrift SemiLight Condensed; font-size: 13px; width: 200%; padding-top: 8px; padding-left: 5px; padding-bottom: 8px;" placeholder= "Search for products, brands and categories"/> </a></li>
      <li style= "margin-left: 35dvh;"><a href= #> Help </a></li> 
      <li class= "div3li6"><a href= login.php> My Account </a></li>
      <li style= > <button class= "btn btn-info"> <a href= "signup.php" style= "color: white;"> My Cart </a> </button> </li>
     </ul>
 </div>

 <div class= "div4">
  <ul class= "ul2">
      <li class= "li2"> <a href= #> <b>All Categories</b> </a> </li>
      <li class= "li2"> <a href= #> Computers and Accessories </a></li>
      <li class= "li2"> <a href= #> Phone and Tablets</a></li>
      <li class= "li2"><a href= #> Electronics </a></li> 
      <li class= "li2"><a href= #> Konga Fashion </a></li>
      <li class= "li2"><a href= #> Home and Kitchen </a> </li>
      <li class= "li2"><a href= #> Baby, Kids and Toys </a> </li>
      <li class= "li2"><a href= #> Other Categories </a> </li>
   </ul>
 </div>

</header> 