<?php  

include 'head.php';
include 'header.php';
?>

<html>
<body class= "sec">
 <div class= "div5"> 
  <ul class= "ul3">
   <li class= "li3"> Home &nbsp;&nbsp;> </p>
   <li class= "li3"> Beauty, Health & Personal Care &nbsp;&nbsp;> </p>
   <li class= "li3"> Hair Centre &nbsp;&nbsp;> </p>
   <li class= "li3" style= "color: #cc0066"> <b>Hair Care and Treatment</b> &nbsp;&nbsp; </p> 
  </ul>

  <h1 style= "margin-top: -5.3vh; margin-left: 3.3vh; padding-bottom: 2.3vh;"> Hair Care </h1>
 </div>

  <div class= "container" style= "margin-top: 2dvh; margin-bottom: 10dvh;">
  
   <div class= "col-md-12" style= " padding-top: 7vh; margin-left: 20dvh; font-size: 15px;">
  <h3 class= "k250"> Kakiva Leave-in Conditioner- 250ml </h3>
  <p class= "k250"> Product Code: 6178153 </p>
  <p class= "k250"> <b>#1,900</b> </p>

  <div class= "imagediv">
   <img style= "width: 50%; margin-top: 17dvh; margin-left: 8vh; padding-left: 7.5vh;" src= "assets/k3.webp" class= "img-zoom">
  </div>
 
    <p style= "margin-top: 8dvh; margin-left: -17dvh;"> Hey. Congrats, your Purchase is successful. You will</br> receive your product(s) very soon in a little Moment </p>
   </div>
  </div>
 
   


<?php
include 'footer.php';
?>
