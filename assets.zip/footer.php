<footer>   
    <p style= "margin-left: 80dvh; font-family: sans-serif; color: #333; " > Copyright &copy; <small>2024 Konga.com. All rights reserved.</small> </p>
</footer>