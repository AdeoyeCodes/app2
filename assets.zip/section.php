<html>
<body class= "sec">
 <div class= "div5"> 
  <ul class= "ul3">
   <li class= "li3"> Home &nbsp;&nbsp;> </p>
   <li class= "li3"> Beauty, Health & Personal Care &nbsp;&nbsp;> </p>
   <li class= "li3"> Hair Centre &nbsp;&nbsp;> </p>
   <li class= "li3" style= "color: #cc0066"> <b>Hair Care and Treatment</b> &nbsp;&nbsp; </p> 
  </ul>

  <h1 style= "margin-top: -5.3vh; margin-left: 3.3vh; padding-bottom: 2.3vh;"> Hair Care </h1>
 </div>

  <div class= "container" style= "margin-top: 2dvh; margin-bottom: 10dvh;">
  
   <div class= "col-md-12" style= " padding-top: 7vh; margin-left: 20dvh; font-size: 15px;">
  <h3 class= "k250"> Kakiva Leave-in Conditioner- 250ml </h3>
  <p class= "k250"> Product Code: 6178153 </p>
  <p class= "k250"> <b>#1,900</b> </p>

  <div class= "imagediv">
   <img style= "width: 50%; margin-top: 17dvh; margin-left: 8vh; padding-left: 7.5vh;" src= "assets/k3.webp" class= "img-zoom">
  </div>
   </div>
  </div>
  
  <form action= "process.php" method= "post">
   <div class= "col-md-6" style= "margin-left: 62dvh; margin-top: -18dvh; padding-bottom: 20dvh; width: 30%;">
    <div class= "btndiv">
    <button class= "btn btn-success" style= "width: 59%;"> Purchase Now </a> </button>
    </div>
   </div>
  </form>

  
</body>
</html>