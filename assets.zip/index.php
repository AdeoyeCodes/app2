<?php  

include 'head.php';
include 'header.php';
include 'section.php';
include 'footer.php';

?>
